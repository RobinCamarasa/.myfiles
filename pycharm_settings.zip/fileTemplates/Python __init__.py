"""
#parse("header.py")

**Module that contains the codes that $function**
"""

MODULE = "$module"
