"""
#parse('header.py')

** File that contains the views of the $app app**
"""
#parse('path_from_submodule.py')
from django.shortcuts import render


def index(request):
    return render(
        request, os.path.join('experiment_vizualizer', 'index.html')
    )