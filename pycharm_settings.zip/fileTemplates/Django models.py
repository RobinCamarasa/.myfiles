"""
#parse('header.py')

** File that contains the models of the app $app**
"""
#parse('path_from_submodule.py')
from django.db import models
