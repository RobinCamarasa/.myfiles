"""
#parse('header.py')

Class that implements #[[$NETWORK$]]# structure
"""
import torch.nn as nn
import torch


class #[[$NETWORK$]]#(nn.Module):
    """
    Class that implements #[[$NETWORK$]]# structure

    :param n_channels: Number of channel of the input
    :param n_classes: Number of channel of the output
    """
    def __init__(
        self, in_channels: int = #[[$IN_CHANNELS$]]#,
        out_channels: int = #[[$OUT_CHANNELS$]]#
    ):
        self.in_channels = in_channels
        self.out_channels = out_channels
        super(#[[$NETWORK$]]#, self).__init__()

    def forward(self, x: torch.Tensor)-> torch.Tensor:
        """
        Method that computes forward pass

        :param x: Tensor value before forward pass
        :return: Tensor value after forward pass
        """
        pass
