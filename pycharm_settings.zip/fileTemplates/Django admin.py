"""
#parse('header.py')

** File that register $app models to the administation page**
"""
#parse('path_from_submodule.py')
from django.contrib import admin

class ${model}Admin(admin.ModelAdmin):
    pass
admin.site.register(${model}, ${model}Admin)

