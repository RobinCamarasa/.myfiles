"""
#parse('header.py')

**File that tests codes of #[[$MODULE$]]# module**
"""

