"""
#parse('header.py')

**File that contains test of $module module**
"""
#parse('path_from_module.py')

