"""
#parse('header.py')

** File that creates the command related to #[[$TAG$]]# **
"""
import click

from data_science_framework.data_spy.options.option_manager import parameters_to_options,\
        initialize_experiment_parameters
from data_science_framework.data_spy.loggers.experiment_loggers import global_logger
import os

# Defining the objects required for your experiments
EXPERIMENT_OBJECTS = {#[[$EXPERIMENT_OBJECTS$]]#}

@click.command()
@parameters_to_options(
    experiment_objects=EXPERIMENT_OBJECTS
)
@global_logger(
        folder=RESULT_ROOT, tag='#[[$TAG$]]#',
        project_root=PROJECT_ROOT
)
def main(index, experiment_folder, **option_values):
    """
    Function that launches a #[[$FUNCTION$]]#
    """
    # Initialize experiment parameters
    initialize_experiment_parameters(
        experiment_objects=EXPERIMENT_OBJECTS,
        option_values=option_values
    )
    #[[$END$]]#

if __name__ == '__main__':
    main()
