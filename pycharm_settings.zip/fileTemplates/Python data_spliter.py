import os

from data_science_framework.data_spy.loggers.experiment_loggers import timer
from data_science_framework.scripting.file_structure_manager import get_dir_structure

class #[[$DATASPLITTER$]]#:
    """
    Class that handle data splitting

    :param data_id: Version of your data
    """
    def __init__(
            self, data_id=#[[$DATA_ID$]]#, #[[$END$]]#
        ):
        # Initialize parameters
        self.data_id = data_id
        self.data_ressources = get_dir_structure(
            os.path.join(DATA_ROOT, str(data_id))
        )


    @timer
    def split_data(self, *args, **kwargs):
        """
        Function that splits dataset
        
        :return:
        """
        pass
