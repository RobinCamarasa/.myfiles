"""
#parse('header.py')

**File that contains $module apps configuration**
"""
#parse('path_from_submodule')
from django.apps import AppConfig


class $configclass(AppConfig):
    name = '$module'
