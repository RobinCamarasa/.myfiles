"""
#parse('header.py')

** Settings of the project **
"""
import os
import sys

# Create project paths
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_ROOT = #[[$DATA_ROOT$]]#
RESULT_ROOT = #[[$RESULT_ROOT$]]#

# Test
TEST_ROOT = #[[$TEST_ROOT$]]#
RESSOURCES_ROOT = #[[$RESULT_ROOT$]]#
