"""
#parse('header.py')

**This class ${function}**
"""

#parse('path_from_module')

#parse('class.py')