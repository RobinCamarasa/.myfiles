@click.command()
def main() -> None:
    """
    $main_purpose
    """
    # Launch experiment
    _, experiment_utils = launch_experiment(
        module='$module',
        subdirectories=[],
        configuration=locals()
    )
    

@click.command()
def clear() -> None:
    """
    This function clears the results folder
    """
    # Clear experiment folder
    clear_experiment_folders(
        results_path=os.path.join(RESULTS_ROOT, '$module')
    )