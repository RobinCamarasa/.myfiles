.. click:: ${PROJECT_NAME}.${module}.commands:evaluate
  :prog: evaluate
  :show-nested: