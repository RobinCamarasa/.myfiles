@click.command()
def clear() -> None:
    """
    This function clears the results folder
    """
    # Clear experiment folder
    clear_experiment_folders(
        module=MODULE
    )