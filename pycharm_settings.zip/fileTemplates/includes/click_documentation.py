.. click:: data_science_project.${module}.commands:main
  :prog: main
  :show-nested:
.. click:: data_science_project.${module}.commands:clear
  :prog: clear
  :show-nested: