@click.command()
@click.option(
    'id', type=int, show_default=True,
    default=None, help='Id of the experiment under study'
)
def evaluate(id: int) -> None:
    """
    This function evaluates an experiment
    """
    tested_folder, id = initiate_evaluation(module=MODULE, id=id)
