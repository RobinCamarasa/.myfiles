.. click:: ${PROJECT_NAME}.${module}.commands:main
  :prog: main
  :show-nested: