.. click:: ${PROJECT_NAME}.${module}.commands:clear
  :prog: clear
  :show-nested: