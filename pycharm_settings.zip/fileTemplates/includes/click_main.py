if __name__ == '__main__':
    cli.add_command(main)
    cli.add_command(clear)
    cli()