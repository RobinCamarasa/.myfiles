@click.command()
def main() -> None:
    """
    This function $main_purpose
    """
    # Launch experiment
    _, experiment_utils = launch_experiment(
        module=MODULE,
        subdirectories=[],
        configuration=locals()
    )