class ${NAME}():
    """
    Class that ${function}
    
    """
    def __init__(self):
        pass

