#!/bin/sh

# Go to documentation root
cd $1

#Delete old rst files
rm ./source/${PROJECT_NAME}.*
rm ./source/personal_frameworks.*

# Generate new rst files
figlet REFRESH
sphinx-apidoc .. -o ./source

# Generate documentation
figlet GENERATE
make html

# Display documentation

figlet DISPLAY
firefox ./build/html/index.html