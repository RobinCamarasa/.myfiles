"""
#parse('header.py')

** Contains the test of the $app app**
"""
#parse('path_from_submodule')
from django.test import TestCase

# Create your tests here.