"""
#parse('header.py')

Class that $classfunction
"""
#parse('path_from_submodule')
import torch.nn as nn
import torch


class ${NAME}(nn.Module):
    """
    Class that $classfunction

    :param n_channels: Number of channel of the input
    :param n_classes: Number of channel of the output
    """
    def __init__(self, n_channels: int, n_classes: int):
        super(${NAME}, self).__init__()

    def forward(self, x: torch.Tensor)-> torch.Tensor:
        """
        Method that computes forward pass

        :param x: Tensor value before forward pass
        :return: Tensor value after forward pass
        """
        pass
