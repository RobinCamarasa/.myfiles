"""
#parse("header.py")

** File that contains code that $filefonction **
"""

#parse('path_from_submodule')