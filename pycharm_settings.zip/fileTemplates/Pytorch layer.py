"""
#parse('header.py')

**Class that contains ${classfunction}**
"""
#parse('path_from_submodule.py')
import torch.nn as nn
import torch


class ${NAME}(nn.Module):
    """
    Class that contains ${classfunction}

    :param in_channels: Number of channel of the input
    :param out_channels: Number of channel of the output
    """
    
    def __init__(
        self, in_channels: int, out_channels: int
    ) -> None:
        super().__init__()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Method that computes forward pass

        :param x: Tensor value before forward pass
        :return: Tensor value after forward pass
        """
        pass
