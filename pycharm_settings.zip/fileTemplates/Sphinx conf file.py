import os
import sys

sys.path.append(
    os.path.abspath(__file__)
)
sys.path.append(
    os.path.dirname(
        os.path.dirname(
                os.path.abspath(__file__)
        )
    )
)
sys.path.append(
    os.path.dirname(
        os.path.dirname(
            os.path.dirname(
                os.path.abspath(__file__)
            )
        )
    )
)

project = '$project_name'
copyright = '2019, $authors'
author = '$authors'

extensions = [
    'sphinx.ext.autodoc',
    'sphinx_click.ext',
    'sphinx.ext.viewcode'
]

templates_path = ['_templates']

exclude_patterns = []

html_theme = 'classic'

html_static_path = ['_static']

autodoc_mock_imports = ['setup']