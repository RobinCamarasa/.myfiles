"""
#parse("header.py")

**File that is an entry point for commands related to $module module**

#parse("click_documentation.py")

"""

import click

#parse("path_from_module.py")

from data_science_project.utils.file_manager import *

#parse("path_from_module.py")

#parse("click_group.py")

#parse("click_commands.py")

#parse("click_main.py")
