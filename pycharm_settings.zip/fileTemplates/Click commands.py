"""
#parse("header.py")

**File that is an entry point for commands related to $module module**

#parse("click_documentation_main.py")

#parse("click_documentation_evaluate.py")

#parse("click_documentation_clear.py")
"""
import click
#parse("path_from_module.py")

from ${PROJECT_NAME}.utils_project.file_manager import *


#parse("click_group.py")

#parse("click_command_main.py")

#parse("click_command_evaluate.py")

#parse("click_command_clear.py")

#parse("click_main.py")
