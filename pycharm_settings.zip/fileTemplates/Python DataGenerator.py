"""
#parse('header.py')

** Class that implements #[[$DataGenerator$]]# **

"""
import os

from data_science_framework.data_spy.loggers.experiment_loggers import timer


class #[[$DataGenerator$]]#(Dataset):
    """
    Class that generates data

    :param dataframe: Dataframe containing data
    :param rotation: True if rotation is enabled
    :param rotation_max_angle: Maximum angle of the rotation
    :param horizontal_flip: True if horizontal flip is enabled
    :param vertical_flip: True if vertical flip is enabled
    """
    def __init__(
            self, dataframe=None, data_path=None, #[[$END$]]#
        ):
        super(#[[$DataGenerator$]]#, self).__init__()

    @timer
    def __getitem__(self, idx, *args, **kwargs):
        # Get indices
        if torch.is_tensor(idx):
            idx = idx.tolist()
        if type(idx) == int:
            idx = [idx]
        pass

    def __len__(self):
        return len(self.dataframe)