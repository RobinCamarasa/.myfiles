"""
#parse('header.py')

** File that contains the routes of the website **
"""
#parse('path_from_submodule.py')
from django.contrib import admin
from django.urls import path

urlpatterns = [
    path('admin/', admin.site.urls),
]